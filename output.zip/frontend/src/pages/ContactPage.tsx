import React from 'react'

const ContactPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Contact</h1>
      <p className="text-gray-600">Contact form and details will go here.</p>
      {/* Add contact form, map, info */}
    </div>
  )
}

export default ContactPage